package com.example.studentnote.repository

@Module
@InstallIn(ViewModelComponent::class)
abstract class StudentRepositoryModule {
    @Binds
    abstract fun bindQuestionRepository(
        questionRepositoryImpl: StudentNoteRepositoryDummyImpl):
            QuestionRepository

}