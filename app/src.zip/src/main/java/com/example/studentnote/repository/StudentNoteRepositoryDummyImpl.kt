package com.example.studentnote.repository

import com.example.studentnote.data.Student
import com.example.studentnote.data.StudentResponse
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow

class StudentNoteRepositoryDummyImpl @Inject constructor() : StudentNoteRepository {
    ovveride val studentResponse = MutableSharedFlow<StudentResponse>()
    override suspend fun updateStudentList() {
        studentResponse.emit(StudentResponse.Pending)

        delay(1000)
        studentResponse.emit(
            StudentResponse.Success(
                listOf(
                    Student(
                        1,
                        "PARIS",
                        "Mathématiques",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet.",
                        30
                    ),
                    Student(
                        2,
                        "PARIS",
                        "Français",
                        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed non risus. Suspendisse lectus tortor, dignissim sit amet.",
                        30
                    )
                )
            )
        )
    }
}
