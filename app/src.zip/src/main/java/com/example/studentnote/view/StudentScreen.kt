package com.example.studentnote.view
import com.example.studentnote.R
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.studentnote.data.Student

// Function to determine course
fun courseStudent(s:String): String {
    if (s == "Mathématiques"){
        return "M"
    } else {
        return "F"
    }
}

@Composable
fun StudentScreen(
    modifier: Modifier,
    studentListViewModel: StudentNoteListViewModel = viewModel()
) {


    val students by studentListViewModel.studentList.observeAsState(emptyList())



    Scaffold(
        modifier = modifier,
        /*
        floatingActionButton = {
            FloatingActionButton(
                onClick = studentListViewModel::
            ) {
                Icon(
                    painter = painterResource(R.drawable.baseline_autorenew_24,
                    contentDescription = stringResource(R.string.refresh_button_description)
                )
            }
        },*/
    ) { innerPadding ->

        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp) // marges gauche/droite
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(students) { it ->
                        StudentRow(it)
                    }
                    item {
                        Spacer ( modifier = Modifier.height(64.dp))
                    }
                }

            }
        }
    }
}

@Composable
fun StudentRow(student: Student, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Top
    ) {
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = student.academie,
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 16.dp)
            )

            Text(
                text = courseStudent(student.discipline),
                fontSize = 16.sp,
                maxLines = 1,
                modifier = Modifier.padding(top = 4.dp, end = 16.dp)
            )

            Text(
                text = student.competences,
                style = MaterialTheme.typography.headlineSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(end = 16.dp)
            )

            Text(
                text = "${student.taux.toInt()} %%",
                style = MaterialTheme.typography.displaySmall,
                modifier = Modifier.padding(start = 16.dp)
            )
        }


    }
}

