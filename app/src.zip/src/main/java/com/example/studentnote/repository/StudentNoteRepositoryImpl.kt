package com.example.studentnote.repository

import com.example.studentnote.data.Student
import com.example.studentnote.data.StudentResponse
import com.example.studentnote.webservice.StudentNoteWebService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import okio.IOException

class StudentNoteRepositoryImpl @Inject constructor(
    private val studentNoteWebService: StudentNoteWebService,
): StudentNoteRepository{
    override val studentResponse = MutableSharedFlow<StudentResponse>()

    override suspend fun updateListStudent() {
        try {
            studentResponse.emit(StudentResponse.Pending)
            val list = studentNoteWebService.getStudentsList(100)
            studentResponse.emit(StudentResponse.Success(list)
            )
        } catch (e: IOException) {
            studentResponse.emit(StudentResponse.Success(emptyList()))
        }
    }
}