package com.example.studentnote.data

import com.squareup.moshi.FromJson
import com.squareup.moshi.ToJson

class StudentMoshiAdapter {
    @FromJson
    fun fromJson(studentNoteJson: StudentNoteListJson): List<StudentJson> {
        return studentNoteJson.results.map{
                studentJson -> StudentJson(studentJson.id, studentJson.libelle_academie,
                studentJson.dscipline, studentJson.competence, studentJson.taux_de_maitrise)
        }
    }
}